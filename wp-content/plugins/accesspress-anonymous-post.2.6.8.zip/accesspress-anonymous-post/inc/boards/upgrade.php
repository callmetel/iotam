<div class="ap-tabs-board" id="board-upgrade-settings" style="display: none;">
<h2><?php _e('Upgrade','accesspress-anonymous-post');?></h2>
	<div class="ap-tab-wrapper">
		
		<p><strong>Price:</strong> $25<br /><br />
        <strong>Upgrades</strong>: Free lifetime upgrades </p>
		<div class="upgrade"><a href="http://codecanyon.net/item/accesspress-anonymous-post-pro/9160446?ref=AccessKeys" target="_blank">Upgrade now! </a></div>
	   <hr />
		<h3 class="feature-title">Pro features </h3>
        <div class="ap-promo-img">
            <img src="<?php echo AP_IMAGE_DIR.'/sales-image-1.jpg';?>" style="text-align: center;"/>
            <img src="<?php echo AP_IMAGE_DIR.'/sales-image-2.jpg';?>" style="text-align: center;"/>
        </div>
		

	</div>
</div>